
Family Pop Party - Web Quiz Game (repo ready for GitHub Pages)
============================================================

Περιεχόμενα του ZIP:
- index.html             : Το κύριο HTML αρχείο (dark theme)
- assets/avatars/*.png   : 12 PNG avatar εικόνες (512x512)
- assets/avatars/*.svg   : 12 SVG fallback avatars
- data/questions_el.json : Το τοπικό pool ελληνικών ερωτήσεων (~220 ερωτήσεις)
- README.md              : Αυτό το αρχείο

Οδηγίες (γρήγορα)
------------------
1. Αποσυμπίεσε το ZIP στον υπολογιστή σου.
2. Δημιούργησε ένα νέο public GitHub repository και ανέβασε τα αρχεία (ή κάνε push από το τοπικό folder).
3. Στο GitHub: Settings -> Pages -> Source -> Επιλέγεις 'main' branch και / (root). Αποθήκευση.
4. Μετά από λίγα λεπτά, το site θα είναι διαθέσιμο στο: https://<your-username>.github.io/<repo-name>/
5. Άνοιξε το URL στο Safari του iPhone — το παιχνίδι θα τρέξει. Στο iPhone μπορείς να προσθέσεις το site στο Home Screen για native-like εμπειρία.

Σημειώσεις
---------
- Το παιχνίδι δουλεύει offline χρησιμοποιώντας το data/questions_el.json.
- Αν θέλεις, μετά το ανεβάσω εγώ και σου δώσω το link (μπορώ να φιλοξενήσω προσωρινά), ή αν προτιμάς να το ανεβάσεις εσύ, σε καθοδηγώ βήμα-βήμα.
- Αν θέλεις περισσότερα avatar ή τροποποιήσεις, πες μου και θα τα προσθέσω.
